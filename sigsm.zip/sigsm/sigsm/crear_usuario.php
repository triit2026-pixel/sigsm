<?php
// Crea un funcionario desde la consola (no se puede ejecutar desde el navegador).
// Uso:  php crear_usuario.php "Nombre Apellido" correo@hospital.uy
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
if ($argc < 3) {
    exit("Uso: php crear_usuario.php \"Nombre Apellido\" correo@hospital.uy\n");
}

require __DIR__ . '/conexion.php';

$nombre = trim($argv[1]);
$email  = trim($argv[2]);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("El correo no es válido.\n");
}

echo "Contraseña (mínimo 8 caracteres): ";
$clave = trim(fgets(STDIN));
if (strlen($clave) < 8) {
    exit("La contraseña es demasiado corta.\n");
}

try {
    $stmt = $pdo->prepare("INSERT INTO usuario (nombre, email, password_hash, rol) VALUES (:n, :e, :p, 'funcionario')");
    $stmt->execute([
        ':n' => $nombre,
        ':e' => $email,
        ':p' => password_hash($clave, PASSWORD_DEFAULT),
    ]);
    echo "Funcionario creado correctamente.\n";
} catch (PDOException $e) {
    echo $e->getCode() === '23000' ? "Ya existe un usuario con ese correo.\n" : "Error: " . $e->getMessage() . "\n";
}
