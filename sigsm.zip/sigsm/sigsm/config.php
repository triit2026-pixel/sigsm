<?php
// Configuración general. En producción: usuario de BD propio (no root) y contraseña.
return [
    'db' => [
        'host'    => '127.0.0.1',
        'nombre'  => 'sigsm',
        'usuario' => 'root',
        'clave'   => '',
        'charset' => 'utf8mb4',
    ],
    // URL pública donde vive el sistema (SIN barra final). Es la que queda impresa en el QR,
    // así que en producción debe ser la dirección real del hospital, no "localhost".
    'base_url' => 'http://192.168.1.4/sigsm/sigsm',
    'max_pdf_mb' => 10,
    'por_pagina' => 15,
];
