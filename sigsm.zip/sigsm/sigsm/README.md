# S.I.G.S.M. — Módulo de gestión de documentación para pacientes

## Puesta en marcha
1. Copia la carpeta `sigsm/` dentro de `htdocs` (XAMPP) o la carpeta pública de tu servidor.
2. En MySQL, ejecuta `sql/schema.sql` sobre la base `sigsm`.
   (Borra la tabla `documento` anterior de pruebas y crea usuario, categoria y documento nuevas.)
3. Revisa `config.php`: datos de la BD y `base_url` (la URL real que irá impresa en los QR).
4. Crea el funcionario desde la consola, en la carpeta del proyecto:
   `php crear_usuario.php "Nombre Apellido" correo@hospital.uy`
5. Entra a `http://localhost/sigsm/login.php`.

## PHP: tamaño de subida
Por defecto PHP limita las subidas a 2 MB. En `php.ini` ajusta `upload_max_filesize` y
`post_max_size` (por ejemplo 12M) y reinicia Apache. Requiere la extensión `fileinfo` activa.

## Estructura
- `login.php`, `logout.php`, `crear_usuario.php` — acceso del funcionario
- `categorias.php` — alta, renombrado y activación de categorías
- `documentos.php` — listado con búsqueda, filtro por categoría/estado y paginación
- `alta_documento.php`, `editar_documento.php` — formularios con subida real de PDF
- `baja_documento.php`, `reactivar_documento.php` — baja lógica y reactivación
- `qr_documento.php` — muestra, imprime y descarga el QR de un documento
- `ver.php` — página pública que abre el paciente al escanear el QR (sin login)
- `includes/` — funciones, sesión/CSRF, cabecera, pie y formulario compartido
- `storage/documentos/` — PDFs con nombre aleatorio (bloqueado por .htaccess; solo se sirven vía `ver.php`)

## Ideas para después
Contraseña olvidada, límite de intentos de login, HTTPS (`secure` en la cookie de sesión),
rol de administrador, exportar métricas de escaneos.
