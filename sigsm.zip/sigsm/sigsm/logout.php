<?php
require 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $_SESSION = [];
    session_destroy();
}
redirigir('login.php');
