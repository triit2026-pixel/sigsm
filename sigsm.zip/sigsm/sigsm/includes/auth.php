<?php
// Sesión, autenticación y protección CSRF
require_once __DIR__ . '/funciones.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        // 'secure' => true,   // activar cuando el sitio se sirva por HTTPS
    ]);
    session_start();
}

function usuario_actual(): ?array {
    return $_SESSION['usuario'] ?? null;
}

function requerir_login(): void {
    if (!usuario_actual()) {
        redirigir('login.php');
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verificar(): void {
    $enviado = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $enviado)) {
        http_response_code(403);
        exit('Solicitud no válida. Vuelve atrás, recarga la página e inténtalo de nuevo.');
    }
}
