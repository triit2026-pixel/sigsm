<?php
require_once __DIR__ . '/auth.php';
$tituloPagina = $tituloPagina ?? 'S.I.G.S.M.';
$usuario = usuario_actual();
$flash = flash_tomar();
$paginaActual = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($tituloPagina) ?> — S.I.G.S.M.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php if ($usuario): ?>
<nav class="navbar navbar-expand-md navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="documentos.php">S.I.G.S.M.</a>
        <ul class="navbar-nav me-auto">
            <li class="nav-item">
                <a class="nav-link <?= $paginaActual === 'documentos.php' ? 'active' : '' ?>" href="documentos.php">Documentos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $paginaActual === 'categorias.php' ? 'active' : '' ?>" href="categorias.php">Categorías</a>
            </li>
        </ul>
        <span class="navbar-text me-3"><?= e($usuario['nombre']) ?></span>
        <form action="logout.php" method="post" class="d-flex">
            <?= csrf_campo() ?>
            <button type="submit" class="btn btn-sm btn-outline-light">Salir</button>
        </form>
    </div>
</nav>
<?php endif; ?>
<div class="container pb-4">
<?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['tipo']) ?>"><?= e($flash['mensaje']) ?></div>
<?php endif; ?>
